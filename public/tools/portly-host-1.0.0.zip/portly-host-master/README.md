portly-host
===========

Install portly-host into your Wordpress `/wp-content/plugins` folder and activate.  No other configuration is needed.

You'll be able to access your Wordpress server locally or via your Portly URL without additional configuration.  
